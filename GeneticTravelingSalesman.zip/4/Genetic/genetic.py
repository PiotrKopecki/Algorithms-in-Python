import numpy as np
import random

from utils import fitness


class Genetic:
    def __init__(self, coords, population_size=100, elite_size=10, mutation_rate=0.01):
        self.coords = coords
        self.population_size = population_size
        self.elite_size = elite_size
        self.mutation_rate = mutation_rate

    #Gene - coords
    #individual - pojedyncza trasa
    #population - zbiór możliwych tras

    #Fitness functuon -  jak krótki jest dystans
    def population_fitness(self, population):
        population_fitness = {}
        for i, individual in enumerate(population):
            # 1/fitness -> change to maximization problem
            population_fitness[i] = 1/fitness(self.coords, individual)

        return {k: v for k, v in sorted(population_fitness.items(), key=lambda item: item[1], reverse=True)}

    def best_solution(self, population):
        population_fitness = list(self.population_fitness(population))
        best_ind = population_fitness[0]
        return population[best_ind]

    def initial_population(self):
        population = []
        # Create initial population
        for i in range(self.population_size):
            solution = np.random.permutation(len(self.coords))
            population.append(solution)

        return population

    def selection(self, population): # wybieramy najlepszych osobnikow z pokolenia jako rodzicow nastepnego
        # TODO: implement selection
        population_fitness = self.population_fitness(population)

        probability = {}
        selection = []
        sum_fitness = sum(population_fitness.values())
        probability_previous = 0

        for key, value in population_fitness.items():
            probability[key] = probability_previous + value / sum_fitness
            probability_previous = probability[key]

        for i in range(len(population)):
            rand = random.random()
            for key, value in probability.items():
                if rand <= value or i < 10:
                    selection.append(population[key])
                    break

        return selection

    def crossover_population(self, population): #pomieszanie osobnikow i wstawienie do nowego pokolenia
        # TODO: implement crossover
        new_population = []
        for i in range(10):
            new_population.append(population[i])
        for i in range(90):
            parent1 = random.choice(population)
            parent2 = random.choice(population)

            firstIndex = random.randrange(len(parent1))
            lastIndex = random.randrange(len(parent1))

            slice = parent1[firstIndex:lastIndex]
            new_coords = np.array([x for x in parent2 if x not in slice])
            #new_population.append(parent1)
            final = np.append(new_coords, slice)
            new_population.append(final)
        return new_population

    def mutate_population(self, population): #losowa zmiana dwoch miast w trasie
        # TODO: implement mutation
        for i, p in enumerate(population):
            rand = random.random()
            if rand <= self.mutation_rate and i > 10:
                r1 = random.randrange(0, len(p))
                r2 = random.randrange(0, len(p))
                p[[r1, r2]] = p[[r2, r1]]

        return population

    def next_generation(self, population):
        selection = self.selection(population)
        children = self.crossover_population(selection)
        next_generation = self.mutate_population(children)
        return next_generation
