from maze import Maze, path_from
from heapq import *

def distance(child, end_node):
    return abs(child.x - end_node.x) + abs(child.y - end_node.y)

def greedy(maze):
    start_node = maze.find_node('S')
    start_node.visited = True
    end_node = maze.find_node('E')
    start_node.cost = distance(start_node, end_node)
    q = []
    id = 0
    heappush(q, (start_node.cost, id, start_node))
    while len(q) > 0:
        node = heappop(q)[2] #
        node.visited = True
        if node.type == 'E':
            return path_from(node)
        children = maze.get_possible_movements(node)
        for child in children:
            if not child.visited:
                child.parent = node
                child.cost = distance(child, end_node)
                id+=1
                heappush(q, (child.cost, id, child))

    return None


maze = Maze.from_file("maze4.txt")
maze.draw()
maze.path = greedy(maze)
print()
maze.draw()
print('path length: ', len(maze.path))
for node in maze.path:
    print(f'({node.x}, {node.y})', end=' ')
print()