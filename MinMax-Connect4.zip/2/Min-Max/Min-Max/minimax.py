import math
import copy


def minmax(depth, state, maximizingPlayer, alpha, beta):
    moves = state.possible_drops()
    if state.game_over:
        if state.wins == 'x':
            return None, 1000
        elif state.wins == 'o':
            return None, -1000
    if depth == 0:
        return None, state.who_has_better_position()

    if maximizingPlayer:
        value = -math.inf
        best_move = None
        for move in moves:
            copy_of_state = copy.deepcopy(state)
            copy_of_state.drop_token(move)
            new_move, score = minmax(depth - 1, copy_of_state, False, alpha, beta)
            if score > value:
                best_move = move
                value = score
            alpha = max(value, alpha)
            if alpha >= beta:
                break
        return best_move, value

    else:  # minimizing player
        value = math.inf
        best_move = None
        for move in moves:
            copy_of_state = copy.deepcopy(state)
            copy_of_state.drop_token(move)
            new_move, score = minmax(depth - 1, copy_of_state, True, alpha, beta)
            if score < value:
                best_move = move
                value = score
            beta = min(beta, value)
            if alpha >= beta:
                break
        return best_move, value
