from maze import Maze, path_from
from heapq import *

def distance(child, end_node):
    return abs(child.x - end_node.x) + abs(child.y - end_node.y)

def djikstra(maze):
    start_node = maze.find_node('S')
    start_node.visited = True

    start_node.cost = 0
    q = []
    id = 0
    heappush(q, (start_node.cost, id, start_node))
    while q:
        node = heappop(q)[2] # PRIORITY QUEUE
        node.visited = True
        if node.type == 'E':
            return path_from(node)

        children = maze.get_possible_movements(node)
        for child in children:
            if not child.visited:
                nowy_koszt = node.moves_cost + maze.move_cost(child)

                if nowy_koszt < child.cost:
                    child.cost = nowy_koszt
                    child.parent = node
                    id += 1
                    heappush(q, (child.cost, id, child))

    return None


maze = Maze.from_file("maze1.txt")
maze.draw()
maze.path = djikstra(maze)
print()
maze.draw()
print('path length: ', len(maze.path))
for node in maze.path:
    print(f'({node.x}, {node.y})', end=' ')
print()